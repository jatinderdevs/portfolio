  <footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-2">
                <div class="logo ">
                     <h3 class="subHeading m-0"><span>]</span><span class="text-white">JATINDER</span><span>DEV</span><span>[</span> <br>
                    
                    </h3>
                </div>
            </div>
            <div class="col-md-4">
                <h5>Services</h5>
                <ul class="footUl">
                    <li >  <a  href="web-developer-designer.php"> <i class="fa fa-dot-circle-o" aria-hidden="true"></i> Web designer & developer</a></li>
                    <li > <a  href="digital-marketing-and-SEO.php"> <i class="fa fa-dot-circle-o" aria-hidden="true"></i> Digital Marketing & SEO</a></li>
                    <li > <a  href="digital-marketing-and-SEO.php"> <i class="fa fa-dot-circle-o" aria-hidden="true"></i> Graphic Design</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <div class="logo">
                    <a href="contact-us.php"  class="btn  custmbtn"> <i class="fa fa-comments-o" aria-hidden="true"></i> Get in Touch</a>
                    <div class="flex socials">
                        <a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
                        <a href=""><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
                        <a href=""><i class="fa fa-envelope-o" aria-hidden="true"></i></a>
                    </div>
                   
                </div>
                
                
            </div>
        </div>

        
  
           
        </div>
      
    </footer>
      <div class="container-fluid">
             <div class="flex p-2" style="background: #dfdfdf;">
            <p class="m-0">All rights reserved.&copy; 2025 Jatinder Singh</p>
            <p class="m-0">Made with <strong class="text-danger"><i class="fa fa-heart" aria-hidden="true"></i></strong> in Melbourne,AU </p>
            </div>
        </div>

        <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/67fe262fd9917b190cb9655f/1ioscab3h';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->